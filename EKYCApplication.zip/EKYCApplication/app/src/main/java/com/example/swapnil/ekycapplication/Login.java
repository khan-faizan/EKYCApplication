package com.example.swapnil.ekycapplication;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;

public class Login extends Activity {
    Button loginButton;
    String usernameStr,passwordStr;
    EditText usernameEt,passwordEt;
    ProgressBar progressBar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        loginButton=(Button)findViewById(R.id.loginbtn);
        usernameEt=(EditText)findViewById(R.id.input_username);
        passwordEt=(EditText)findViewById(R.id.input_password);
        progressBar=(ProgressBar)findViewById(R.id.loginprogressbar) ;


        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressBar.setVisibility(View.VISIBLE);
                usernameStr=usernameEt.getText().toString();
                passwordStr=passwordEt.getText().toString();

                Intent GotoSelectionActivity=new Intent(Login.this,Selectionactivity.class);
                startActivity(GotoSelectionActivity);
                finish();
            }
        });
    }
}
