package com.example.swapnil.ekycapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Capturefingerprint extends AppCompatActivity {
    Button NextBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_capturefingerprint);
        NextBtn=(Button)findViewById(R.id.nextfingerprint);

        NextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent GotoSelectionActivity=new Intent(Capturefingerprint.this,KYC_Form.class);
                startActivity(GotoSelectionActivity);
                finish();
            }
        });
    }
}
