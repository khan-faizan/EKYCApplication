package com.example.swapnil.ekycapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class KYC_Form extends AppCompatActivity {
    Spinner customerTypSpinner,residencySpinner,idtypespinner;
    AutoCompleteTextView nationsList,countryofbirthlist;
    Button NextBtn;
    RadioButton yespep,nopep;
    EditText firstname_et,lastname_et,dnum1_et,dnum2_et,dnum3_et,dnum4_et,dnum5_et,dnum6_et,dnum7_et,dnum8_et,eidnumber_et,eidaddress1_et,eidaddress2_et,eidaddress3_et
            ,profession_et,employer_et,expectedvolume_et,countryList,expectedva_et,mobilenumber_et,email_et;
    String customertyeString,firstname_string,lastname_string,dnum1_string,dnum2_string,dnum3_string,dnum4_string,dnum5_string,dnum6_string,dnum7_string,dnum8_string,
            nationallityString,ReisdentType,eidnumber_string,eid_addressstring1,eid_addressstring2,eid_addressstring3,pepflag_string,profession_string,
            countryofbirth_string,expectedvolume_string,expectedva_string,mobilenum_string,email_string,employer_String;
    JSONObject jsonObject;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kyc__form);
        customerTypSpinner = (Spinner) findViewById(R.id.customertype);
       // residencySpinner = (Spinner) findViewById(R.id.residencystatus);
        idtypespinner = (Spinner) findViewById(R.id.idtype);
        nationsList =  (AutoCompleteTextView)findViewById(R.id.autoCompleteTextView);
        countryList =  (EditText)findViewById(R.id.country);

        firstname_et=(EditText)findViewById(R.id.c_firstname);
        lastname_et=(EditText)findViewById(R.id.c_lastname);
        dnum1_et=(EditText)findViewById(R.id.num1);
        dnum2_et=(EditText)findViewById(R.id.num2);
        dnum3_et=(EditText)findViewById(R.id.num3);
        dnum4_et=(EditText)findViewById(R.id.num4);
        dnum5_et=(EditText)findViewById(R.id.num5);
        dnum6_et=(EditText)findViewById(R.id.num6);
        dnum7_et=(EditText)findViewById(R.id.num7);
        dnum8_et=(EditText)findViewById(R.id.num8);
        profession_et=(EditText)findViewById(R.id.c_profession);
        eidnumber_et=(EditText)findViewById(R.id.eidnumber);
        eidaddress1_et=(EditText)findViewById(R.id.c_addressone);
        eidaddress2_et=(EditText)findViewById(R.id.c_addresstwo);
        eidaddress3_et=(EditText)findViewById(R.id.c_addressthree);
        yespep=(RadioButton)findViewById(R.id.yespep);
        nopep=(RadioButton)findViewById(R.id.nopep);
        employer_et=(EditText)findViewById(R.id.c_employername);
        countryofbirthlist=(AutoCompleteTextView)findViewById(R.id.countryofbirth);
        expectedvolume_et=(EditText)findViewById(R.id.c_expectedannualactivity);
        expectedva_et=(EditText)findViewById(R.id.c_expectedannualactivity);

        mobilenumber_et=(EditText)findViewById(R.id.mobileno) ;
        email_et=(EditText)findViewById(R.id.c_emailid);
        employer_et=(EditText)findViewById(R.id.c_employername);

        NextBtn=(Button)findViewById(R.id.submitkyc);

        String[] Nations_list ={"India","Pakistan","Bangladesh","Phillipines","Nepal","Egypt","Others"};
        String[] Country_list ={"United Arab Emirates","India","Pakistan","Bangladesh","Phillipines","Nepal","Egypt","Others"};


        /**
         * Initialisation Of UI
         */

        ///customertype Spinner Inflater
        List<String> spinnerArray =  new ArrayList<String>();
        spinnerArray.add("Individual");
        spinnerArray.add("Corporate");

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this, android.R.layout.simple_spinner_item, spinnerArray);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        customerTypSpinner.setAdapter(adapter);
        ////////

        ///Residency Spinner Inflater
      /*  List<String> ressidencyArray =  new ArrayList<String>();
        ressidencyArray.add("Resident");
        ressidencyArray.add("Nonresident");

        ArrayAdapter<String> ressidencyadapter = new ArrayAdapter<String>(
                this, android.R.layout.simple_spinner_item, ressidencyArray);

        ressidencyadapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
       residencySpinner.setAdapter(ressidencyadapter);*/
        ////////

        ///Idtype Spinner Inflater
        List<String> idtypeArray =  new ArrayList<String>();
        idtypeArray.add("EID-1");
        idtypeArray.add("EID-2");

        ArrayAdapter<String> idtypeadapter = new ArrayAdapter<String>(
                this, android.R.layout.simple_spinner_item, idtypeArray);

        idtypeadapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//        idtypespinner.setAdapter(idtypeadapter);
        ////////

        //Nationality autocomplete list inflate
        ArrayAdapter<String> countryadapter = new ArrayAdapter<String>
                (this,android.R.layout.select_dialog_item,Nations_list);


        nationsList.setThreshold(1);
        nationsList.setAdapter(countryadapter);

        //


        /**
         * Initialisation Of UI ends
         */


        NextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent GotoSelectionActivity=new Intent(KYC_Form.this,Upload_Documents.class);
                putdataintostring();
                startActivity(GotoSelectionActivity);
                finish();
            }
        });



    }

    public void putdataintostring(){

        customertyeString=customerTypSpinner.getSelectedItem().toString();
        firstname_string=firstname_et.getText().toString();
        lastname_string=lastname_et.getText().toString();
        dnum1_string=dnum1_et.getText().toString();
        dnum2_string=dnum2_et.getText().toString();
        dnum3_string=dnum3_et.getText().toString();
        dnum4_string=dnum4_et.getText().toString();
        dnum5_string=dnum5_et.getText().toString();
        dnum6_string=dnum6_et.getText().toString();
        dnum7_string=dnum7_et.getText().toString();
        dnum8_string=dnum8_et.getText().toString();
        nationallityString=nationsList.getText().toString();
        mobilenum_string=mobilenumber_et.getText().toString();
        email_string=email_et.getText().toString();
       // ReisdentType=residencySpinner.getSelectedItem().toString();
        eidnumber_string=eidnumber_et.getText().toString();
        eid_addressstring1=eidaddress1_et.getText().toString();
        eid_addressstring2=eidaddress2_et.getText().toString();
        eid_addressstring3=eidaddress3_et.getText().toString();
        countryofbirth_string=countryofbirthlist.getText().toString();
        if(yespep.isChecked()){
            pepflag_string="Yes";
        }else{
            pepflag_string="No";
        }
        profession_string=profession_et.getText().toString();

        expectedvolume_string=expectedvolume_et.getText().toString();
        expectedva_string=expectedva_et.getText().toString();
        employer_String=employer_et.getText().toString();
        jsonObject=new JSONObject();
        try {
            jsonObject.put("customertype",customertyeString);
            jsonObject.put("firstname",firstname_string);
            jsonObject.put("lastname",lastname_string);
            jsonObject.put("dateofbirth",dnum1_string+dnum2_string+"-"+dnum3_string+dnum4_string+"-"+dnum5_string+dnum6_string+dnum7_string+dnum8_string);
            jsonObject.put("nationallity",nationallityString);
            jsonObject.put("mobilenumber",mobilenum_string);
            jsonObject.put("email",email_string);
            jsonObject.put("residenttype",ReisdentType);
            jsonObject.put("eidnumber",eidnumber_string);
            jsonObject.put("eidaddress",eid_addressstring1+" "+eid_addressstring2+" "+eid_addressstring3);
            jsonObject.put("countryofbirth",countryofbirth_string);
            jsonObject.put("pep",pepflag_string);
            jsonObject.put("profession",profession_string);
            jsonObject.put("expectedvolume",expectedvolume_string);
            jsonObject.put("expectedva",expectedva_string);
            jsonObject.put("employer",employer_String);
            Toast.makeText(KYC_Form.this, jsonObject.toString(), Toast.LENGTH_SHORT).show();

        } catch (JSONException e) {
            e.printStackTrace();
        }


    }
}
