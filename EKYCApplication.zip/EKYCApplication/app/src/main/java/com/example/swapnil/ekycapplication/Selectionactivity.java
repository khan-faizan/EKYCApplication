package com.example.swapnil.ekycapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

public class Selectionactivity extends AppCompatActivity {
LinearLayout OldCustomerbtn,NewcustomerBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selectionactivity);
        OldCustomerbtn=(LinearLayout) findViewById(R.id.oldcustomerll);
        NewcustomerBtn=(LinearLayout)findViewById(R.id.newcustomerll);


        OldCustomerbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent GotoSelectionActivity=new Intent(Selectionactivity.this,ExistingCustomerList.class);
                startActivity(GotoSelectionActivity);
                finish();
            }
        });

        NewcustomerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent GotoSelectionActivity=new Intent(Selectionactivity.this,Emiratesidverification.class);
                startActivity(GotoSelectionActivity);
                finish();
            }
        });
    }
}
